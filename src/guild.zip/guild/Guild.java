package guild;

public class Guild {
}

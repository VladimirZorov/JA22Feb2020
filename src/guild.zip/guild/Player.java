package guild;

public class Player {
}
